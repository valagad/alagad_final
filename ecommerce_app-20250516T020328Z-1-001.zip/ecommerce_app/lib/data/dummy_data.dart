import '../models/product.dart';

final dummyProducts = [
  Product(
    id: '1',
    name: 'Vintage Camera',
    image: 'assets/images/camera.jpg',
    price: 150.00,
    description: 'A classic 35mm film camera.',
  ),
  Product(
    id: '2',
    name: 'Retro Radio',
    image: 'assets/images/radio.jpg',
    price: 80.00,
    description: 'A vintage radio with AM/FM tuning.',
  ),
  Product(
    id: '3',
    name: 'Typewriter',
    image: 'assets/images/typewriter.jpg',
    price: 120.00,
    description: 'A working vintage typewriter.',
  ),
  Product(
    id: '4',
    name: 'Vintage Clock',
    image: 'assets/images/clock.jpg',
    price: 60.00,
    description: 'A charming 1940s mantel clock.',
  ),
];
