import 'package:flutter/material.dart';

class AppColors {
  static const Color beige = Color(0xFFF5F5DC);
  static const Color rust = Color(0xFFB7410E);
  static const Color olive = Color(0xFF708238);
  static const Color brown = Color(0xFF3E2723);
}
